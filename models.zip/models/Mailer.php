<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar el autoloader de Composer
require_once __DIR__ . '/../vendor/autoload.php';

class Mailer {
    public static function enviarCorreoRecuperacion($destinatario, $enlace) {
        // Cargar variables del .env
        $envPath = __DIR__ . '/../.env';
        $env = file_exists($envPath) ? parse_ini_file($envPath) : [];

        $host = $env['SMTP_HOST'] ?? 'smtp.mailtrap.io';
        $port = $env['SMTP_PORT'] ?? 587;
        $user = $env['SMTP_USER'] ?? '';
        $pass = $env['SMTP_PASS'] ?? '';
        $fromName = $env['SMTP_FROM_NAME'] ?? 'Diesel García';

        $mail = new PHPMailer(true);

        try {
            // Configuración del servidor SMTP
            $mail->isSMTP();
            $mail->Host       = $host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $user;
            $mail->Password   = $pass;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = $port;
            $mail->CharSet    = 'UTF-8';

            // Remitente y Destinatario
            $mail->setFrom($user, $fromName);
            $mail->addAddress($destinatario);

            // Contenido del correo
            $mail->isHTML(true);
            $mail->Subject = 'Restablece tu contraseña - Diesel García';
            $mail->Body    = "
                <div style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>
                    <h2 style='color: #e0c112;'>Diesel García - Recuperación de Contraseña</h2>
                    <p>Has solicitado restablecer el acceso a tu cuenta profesional.</p>
                    <p>Haz clic en el siguiente botón para cambiar tu contraseña (el enlace expirará en 1 hora):</p>
                    <a href='{$enlace}' style='display: inline-block; padding: 12px 24px; background-color: #e0c112; color: #000; text-decoration: none; font-weight: bold; border-radius: 8px; margin-top: 10px;'>Restablecer Contraseña</a>
                    <p style='margin-top: 20px; font-size: 12px; color: #666;'>Si tú no solicitaste este cambio, puedes ignorar este mensaje de forma segura.</p>
                </div>
            ";

            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}